module.exports = {
    shows: require('./shows')
};